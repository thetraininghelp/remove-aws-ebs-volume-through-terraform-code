import boto3

def lambda_handler(event, context):
    volume_id = event['volume_id']
    ec2 = boto3.client('ec2')
    
    try:
        ec2.delete_volume(VolumeId=volume_id)
        return {
            'statusCode': 200,
            'body': f'Volume {volume_id} deleted successfully.'
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': str(e)
        }
